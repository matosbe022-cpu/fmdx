# FM-DX Android 0.4.0 — Receptor nativo como servidor

Esta versão adiciona um modo experimental para usar o receptor FM nativo do aparelho como fonte de um servidor local.

## Como funciona

1. Abra **Receptor nativo / servidor**.
2. Conceda a permissão de captura de áudio.
3. Toque em **Iniciar servidor do receptor**.
4. O aplicativo tenta abrir a fonte Android `RADIO_TUNER`.
5. Se o aparelho expuser essa fonte para aplicativos comuns, o servidor abre uma porta local.
6. Toque em **Copiar endereço do servidor** e abra o endereço em outro celular ou computador na mesma rede Wi-Fi.
7. A página do servidor possui **OUVIR FM** e decodifica o PCM em tempo real usando Web Audio.

## Áudio

O endpoint `/audio.pcm` entrega PCM 16-bit little-endian, 48 kHz, estéreo. O navegador não recebe um arquivo de áudio comum: a página do servidor lê o fluxo continuamente e alimenta o Web Audio API.

## Limitação importante

Android não fornece uma API pública universal para controlar a frequência de todos os sintonizadores FM. O fabricante pode manter o tuner em APIs internas ou exigir um aplicativo privilegiado. O projeto não finge que o recurso existe: ele testa a capacidade disponível e mostra o erro real quando o acesso é recusado.

A TV digital é ainda mais dependente do fabricante/hardware. Por isso a versão 0.4.0 prepara a tela e a arquitetura, mas não afirma que a TV nativa pode ser capturada em qualquer aparelho.

## Rede

O servidor usa uma porta TCP escolhida automaticamente. O endereço deve ser usado na mesma rede local, por exemplo:

`http://192.168.x.x:PORTA/`

A versão atual não implementa autenticação nem publicação automática na internet. Para acesso externo seria necessário adicionar autenticação, HTTPS ou um túnel/retransmissão seguro.
