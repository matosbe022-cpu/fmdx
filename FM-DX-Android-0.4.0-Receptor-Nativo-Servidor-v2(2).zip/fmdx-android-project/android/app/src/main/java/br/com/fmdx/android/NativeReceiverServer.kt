package br.com.fmdx.android

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Experimental local FM receiver server.
 *
 * The app asks Android for MediaRecorder.AudioSource.RADIO_TUNER when the
 * device exposes that source. There is no universal public Android API for
 * tuning every vendor's FM chipset, so this class only reports a working
 * capture path when AudioRecord can actually initialize it.
 *
 * Audio endpoint: little-endian PCM 16-bit, 48 kHz, stereo.
 * The bundled browser client consumes the stream with Web Audio.
 */
class NativeReceiverServer {
    data class Status(
        val running: Boolean,
        val captureAvailable: Boolean,
        val message: String,
        val port: Int
    )

    private var serverSocket: ServerSocket? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    private val running = AtomicBoolean(false)
    private val clients = CopyOnWriteArrayList<Socket>()
    private var lastMessage = "Servidor parado"

    fun start(): Status {
        if (running.get()) return status()

        val source = radioTunerSource()
        if (source == null) {
            lastMessage = "Este Android não expõe a fonte RADIO_TUNER para aplicativos comuns."
            return status()
        }

        val sampleRate = 48000
        val channelMask = AudioFormat.CHANNEL_IN_STEREO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val min = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding)
        if (min <= 0) {
            lastMessage = "O dispositivo não aceitou uma configuração de captura FM."
            return status()
        }

        val record = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .setEncoding(encoding)
                        .build()
                )
                .setBufferSizeInBytes(min * 4)
                .build()
        } catch (e: Throwable) {
            lastMessage = "Falha ao abrir o receptor: ${e.message ?: e.javaClass.simpleName}"
            return status()
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            lastMessage = "O receptor RADIO_TUNER não pôde ser inicializado neste aparelho."
            return status()
        }

        val socket = try {
            ServerSocket(0).apply { reuseAddress = true }
        } catch (e: Exception) {
            record.release()
            lastMessage = "Não foi possível abrir a porta do servidor: ${e.message ?: e.javaClass.simpleName}"
            return status()
        }

        serverSocket = socket
        audioRecord = record
        running.set(true)
        lastMessage = "Servidor ativo. Captura RADIO_TUNER iniciada."

        thread(name = "NativeReceiverAccept") {
            while (running.get()) {
                try {
                    val client = socket.accept().apply { keepAlive = true }
                    clients.add(client)
                    thread(name = "NativeReceiverClient") { handleClient(client) }
                } catch (e: Exception) {
                    if (running.get()) lastMessage = "Erro aceitando conexão do cliente: ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }

        captureThread = thread(name = "NativeReceiverCapture") {
            try {
                record.startRecording()
                val buffer = ByteArray(min.coerceAtLeast(8192))
                while (running.get()) {
                    val count = record.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        val dead = ArrayList<Socket>()
                        clients.forEach { client ->
                            try {
                                val out = client.getOutputStream()
                                out.write(buffer, 0, count)
                                out.flush()
                            } catch (_: Exception) {
                                dead.add(client)
                            }
                        }
                        dead.forEach { removeClient(it) }
                    } else if (count < 0) {
                        lastMessage = "A captura de áudio foi interrompida (AudioRecord=$count)."
                        break
                    }
                }
            } catch (e: Throwable) {
                if (running.get()) lastMessage = "Captura interrompida: ${e.message ?: e.javaClass.simpleName}"
            }
        }

        return status()
    }

    fun stop() {
        running.set(false)
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        clients.forEach { try { it.close() } catch (_: Exception) {} }
        clients.clear()
        captureThread = null
        lastMessage = "Servidor parado"
    }

    fun status(): Status = Status(
        running = running.get(),
        captureAvailable = running.get() && audioRecord != null,
        message = lastMessage,
        port = serverSocket?.localPort ?: 0
    )

    private fun handleClient(socket: Socket) {
        var streaming = false
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val request = reader.readLine() ?: return
            while (reader.readLine()?.isNotEmpty() == true) {}
            val path = request.split(" ").getOrNull(1)?.substringBefore('?') ?: "/"
            when {
                path == "/" || path.startsWith("/index.html") -> sendHtml(socket)
                path == "/status" -> {
                    val json = "{" +
                        "\"running\":${running.get()}," +
                        "\"capture\":${audioRecord != null}," +
                        "\"port\":${serverSocket?.localPort ?: 0}," +
                        "\"sampleRate\":48000," +
                        "\"channels\":2," +
                        "\"format\":\"pcm_s16le\"," +
                        "\"message\":\"${escapeJson(lastMessage)}\"}"
                    sendResponse(socket, "application/json; charset=utf-8", json.toByteArray(), close = true)
                }
                path == "/audio.pcm" -> {
                    sendPcmHeaders(socket)
                    streaming = true
                }
                else -> sendResponse(socket, "text/plain; charset=utf-8", "404".toByteArray(), status = "404 Not Found", close = true)
            }
        } catch (_: Exception) {
        } finally {
            if (!streaming) removeClient(socket)
        }
    }

    private fun sendPcmHeaders(socket: Socket) {
        val headers = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: application/octet-stream\r\n" +
            "X-Audio-Format: pcm_s16le\r\n" +
            "X-Audio-Rate: 48000\r\n" +
            "X-Audio-Channels: 2\r\n" +
            "Cache-Control: no-store, no-cache, must-revalidate\r\n" +
            "Pragma: no-cache\r\n" +
            "Connection: keep-alive\r\n" +
            "\r\n"
        socket.getOutputStream().write(headers.toByteArray(Charsets.US_ASCII))
        socket.getOutputStream().flush()
    }

    private fun sendHtml(socket: Socket) {
        val host = socket.localAddress.hostAddress ?: "127.0.0.1"
        val port = serverSocket?.localPort ?: 0
        val html = """
            <!doctype html>
            <html lang='pt-BR'>
            <head>
              <meta charset='utf-8'>
              <meta name='viewport' content='width=device-width,initial-scale=1'>
              <title>FM-DX Native Receiver</title>
              <style>
                body{font-family:Arial,sans-serif;background:#081522;color:#fff;padding:20px;max-width:760px;margin:auto}
                button{padding:12px 18px;margin:5px;border:0;border-radius:8px;background:#35b6e8;color:#07131c;font-weight:bold}
                .card{background:#132b40;border-radius:12px;padding:16px;margin:12px 0}
                #meter{height:16px;background:#243e52;border-radius:8px;overflow:hidden}
                #bar{height:100%;width:0;background:#35b6e8;transition:width .08s}
                small{color:#9eb8cc}
              </style>
            </head>
            <body>
              <h2>📻 FM-DX — Receptor nativo</h2>
              <div class='card'>
                <div>Servidor: <b>$host:$port</b></div>
                <div id='status'>Preparado</div>
                <div id='meter'><div id='bar'></div></div>
                <button id='start'>▶ OUVIR FM</button>
                <button id='stop'>■ PARAR</button>
              </div>
              <p><small>Áudio: PCM 16-bit little-endian, 48 kHz, estéreo. O navegador decodifica o fluxo em tempo real com Web Audio.</small></p>
              <script>
                let ctx=null, reader=null, stopped=false, nextTime=0, remainder=new Uint8Array(0);
                const statusEl=document.getElementById('status'), bar=document.getElementById('bar');
                function concat(a,b){const x=new Uint8Array(a.length+b.length);x.set(a);x.set(b,a.length);return x;}
                function pcmToBuffer(bytes){
                  const frameBytes=4, frames=Math.floor(bytes.length/frameBytes); if(!frames)return null;
                  const b=bytes.slice(0,frames*frameBytes), dv=new DataView(b.buffer,b.byteOffset,b.byteLength);
                  const ab=ctx.createBuffer(2,frames,48000);
                  const l=ab.getChannelData(0), r=ab.getChannelData(1); let peak=0;
                  for(let i=0;i<frames;i++){const lv=dv.getInt16(i*4,true)/32768, rv=dv.getInt16(i*4+2,true)/32768;l[i]=lv;r[i]=rv;peak=Math.max(peak,Math.abs(lv),Math.abs(rv));}
                  bar.style.width=Math.min(100,Math.round(peak*100))+'%'; return ab;
                }
                async function play(){
                  if(reader)return; stopped=false; remainder=new Uint8Array(0); ctx=new (window.AudioContext||window.webkitAudioContext)({sampleRate:48000});
                  await ctx.resume(); statusEl.textContent='Conectando ao áudio...';
                  const resp=await fetch('/audio.pcm',{cache:'no-store'}); if(!resp.ok||!resp.body)throw new Error('Falha no fluxo de áudio');
                  reader=resp.body.getReader(); nextTime=ctx.currentTime+0.08; statusEl.textContent='🔊 Ouvindo FM';
                  while(!stopped){
                    const {value,done}=await reader.read(); if(done)break;
                    let data=concat(remainder,value||new Uint8Array()); const usable=data.length-data.length%4; remainder=data.slice(usable);
                    if(!usable)continue; const ab=pcmToBuffer(data.slice(0,usable)); if(!ab)continue;
                    const src=ctx.createBufferSource(); src.buffer=ab; src.connect(ctx.destination); const t=Math.max(nextTime,ctx.currentTime+0.02); src.start(t); nextTime=t+ab.duration;
                    if(nextTime-ctx.currentTime>0.8) await new Promise(r=>setTimeout(r,Math.min(120,(nextTime-ctx.currentTime)*500)));
                  }
                }
                async function stop(){stopped=true;try{await reader?.cancel();}catch(e){}reader=null;if(ctx){try{await ctx.close();}catch(e){}}ctx=null;statusEl.textContent='Parado';bar.style.width='0%';}
                document.getElementById('start').onclick=()=>play().catch(e=>{statusEl.textContent='Erro: '+e.message;reader=null;});
                document.getElementById('stop').onclick=stop;
                fetch('/status').then(r=>r.json()).then(x=>statusEl.textContent=x.message).catch(()=>statusEl.textContent='Servidor ativo');
              </script>
            </body></html>
        """.trimIndent()
        sendResponse(socket, "text/html; charset=utf-8", html.toByteArray(Charsets.UTF_8), close = true)
    }

    private fun sendResponse(
        socket: Socket,
        contentType: String,
        body: ByteArray,
        status: String = "200 OK",
        close: Boolean
    ) {
        val connection = if (close) "close" else "keep-alive"
        val header = "HTTP/1.1 $status\r\nContent-Type: $contentType\r\nContent-Length: ${body.size}\r\nConnection: $connection\r\n\r\n"
        val out = socket.getOutputStream()
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(body)
        out.flush()
        if (close) try { socket.close() } catch (_: Exception) {}
    }

    private fun removeClient(socket: Socket) {
        clients.remove(socket)
        try { socket.close() } catch (_: Exception) {}
    }

    private fun escapeJson(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")

    private fun radioTunerSource(): Int? {
        return try {
            MediaRecorder.AudioSource::class.java.getField("RADIO_TUNER").getInt(null)
        } catch (_: Throwable) {
            null
        }
    }
}
